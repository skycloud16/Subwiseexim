/**
 * WISE EXIM - Central Product Catalog & Brochure Configuration Data
 * Every product is configured with its specific details and individual PDF brochure path.
 */

const PRODUCTS_DATA = [
  {
    id: "submersible-motor-standard",
    name: "Submersible Motor – Product Model",
    category: "motors",
    image: "assets/images/submersible-motor.png",
    description: "Stainless steel submersible motor designed for water pumping systems and industrial water supply operations.",
    specsNote: "Product specifications will be updated based on the final product catalogue.",
    brochure: "assets/brochures/submersible-motor-standard.pdf",
    brochureFileName: "submersible-motor-product-model-brochure.pdf"
  },
  {
    id: "submersible-motor-heavy-duty",
    name: "Submersible Motor – Heavy Duty Model",
    category: "motors",
    image: "assets/images/hero-motor.png",
    description: "Engineered for continuous underwater performance in commercial agricultural and wholesale distribution setups.",
    specsNote: "Product specifications will be updated based on the final product catalogue.",
    brochure: "assets/brochures/submersible-motor-heavy-duty.pdf",
    brochureFileName: "submersible-motor-heavy-duty-brochure.pdf"
  },
  {
    id: "stator-winding-assembly",
    name: "Submersible Motor Stator & Winding",
    category: "parts",
    image: "assets/images/motor-parts.png",
    description: "High grade stator core assemblies and copper winding components for submersible motor maintenance.",
    specsNote: "Product specifications will be updated based on the final product catalogue.",
    brochure: "assets/brochures/stator-winding-assembly.pdf",
    brochureFileName: "stator-winding-assembly-brochure.pdf"
  },
  {
    id: "rotor-shaft-thrust-bearing",
    name: "Rotor Shaft & Thrust Bearing Assembly",
    category: "parts",
    image: "assets/images/motor-parts.png",
    description: "Precision machined stainless steel rotor shafts, thrust bearings, and mechanical seals for submersible pumps.",
    specsNote: "Product specifications will be updated based on the final product catalogue.",
    brochure: "assets/brochures/rotor-shaft-thrust-bearing.pdf",
    brochureFileName: "rotor-shaft-thrust-bearing-brochure.pdf"
  },
  {
    id: "control-panel-starter-unit",
    name: "Control Panel Box & Starter Unit",
    category: "components",
    image: "assets/images/related-components.png",
    description: "Protection and control switchgear enclosures designed for submersible motor electrical installations.",
    specsNote: "Product specifications will be updated based on the final product catalogue.",
    brochure: "assets/brochures/control-panel-starter-unit.pdf",
    brochureFileName: "control-panel-starter-unit-brochure.pdf"
  },
  {
    id: "submersible-cable-accessories",
    name: "Submersible Cable & Accessories",
    category: "components",
    image: "assets/images/related-components.png",
    description: "Heavy duty flat submersible power cables, jointing kits, and installation accessories.",
    specsNote: "Product specifications will be updated based on the final product catalogue.",
    brochure: "assets/brochures/submersible-cable-accessories.pdf",
    brochureFileName: "submersible-cable-accessories-brochure.pdf"
  }
];

/**
 * Category level brochure mapping for overview sections
 */
const CATEGORY_BROCHURES = {
  "motors": {
    path: "assets/brochures/submersible-motor.pdf",
    fileName: "submersible-motor-brochure.pdf"
  },
  "parts": {
    path: "assets/brochures/submersible-motor-parts.pdf",
    fileName: "submersible-motor-parts-brochure.pdf"
  },
  "components": {
    path: "assets/brochures/related-components.pdf",
    fileName: "related-components-brochure.pdf"
  }
};
